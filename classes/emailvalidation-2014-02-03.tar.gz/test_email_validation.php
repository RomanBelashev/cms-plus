<?php
/*
 * test_email_validation.html
 *
 * @(#) $Header: /opt2/ena/metal/emailvalidation/test_email_validation.php,v 1.12 2011/06/10 05:36:40 mlemos Exp $
 *
 */

?><HTML>
<HEAD>
<TITLE>Test for Manuel Lemos's PHP E-mail validation class</TITLE>
</HEAD>
<BODY>
<H1><CENTER>Test for Manuel Lemos's PHP E-mail validation class</CENTER></H1>
<HR>
<?php
	require("email_validation.php");

	$validator=new email_validation_class;

	/*
	 * If you are running under Windows or any other platform that does not
	 * have enabled the MX resolution function GetMXRR() , you need to
	 * include code that emulates that function so the class knows which
	 * SMTP server it should connect to verify if the specified address is
	 * valid.
	 */
	if(!function_exists("GetMXRR"))
	{
		/*
		 * If possible specify in this array the address of at least on local
		 * DNS that may be queried from your network.
		 */
		$_NAMESERVERS=array();
		include("getmxrr.php");
	}
	/*
	 * If GetMXRR function is available but it is not functional, you may
	 * use a replacement function.
	 */
	/*
	else
	{
		$_NAMESERVERS=array();
		if(count($_NAMESERVERS)==0)
			Unset($_NAMESERVERS);
		include("rrcompat.php");
		$validator->getmxrr="_getmxrr";
	}
	*/

	/* how many seconds to wait before each attempt to connect to the
	   destination e-mail server */
	$validator->timeout=10;

	/* how many seconds to wait for data exchanged with the server.
	   set to a non zero value if the data timeout will be different
		 than the connection timeout. */
	$validator->data_timeout=0;

	/* user part of the e-mail address of the sending user
	   (info@phpclasses.org in this example) */
	$validator->localuser="info";

	/* domain part of the e-mail address of the sending user */
	$validator->localhost="phpclasses.org";

	/* Set to 1 if you want to output of the dialog with the
	   destination mail server */
	$validator->debug=1;

	/* Set to 1 if you want the debug output to be formatted to be
	displayed properly in a HTML page. */
	$validator->html_debug=1;


	/* When it is not possible to resolve the e-mail address of
	   destination server (MX record) eventually because the domain is
	   invalid, this class tries to resolve the domain address (A
	   record). If it fails, usually the resolver library assumes that
	   could be because the specified domain is just the subdomain
	   part. So, it appends the local default domain and tries to
	   resolve the resulting domain. It may happen that the local DNS
	   has an * for the A record, so any sub-domain is resolved to some
	   local IP address. This  prevents the class from figuring if the
	   specified e-mail address domain is valid. To avoid this problem,
	   just specify in this variable the local address that the
	   resolver library would return with gethostbyname() function for
	   invalid global domains that would be confused with valid local
	   domains. Here it can be either the domain name or its IP address. */
	$validator->exclude_address="";

	if(IsSet($_GET["email"]))
		$email=$_GET["email"];
	if(IsSet($email)
	&& strcmp($email,""))
	{
		if(strlen($error = $validator->ValidateAddress($email, $valid)))
		{
			echo "<H2><CENTER>Error: ".HtmlSpecialChars($error)."</CENTER></H2>\n";
		}
		elseif(!$valid)
			echo "<H2><CENTER><TT>$email</TT> is not a valid deliverable e-mail box address.</CENTER></H2>\n";
		elseif(($result=$validator->ValidateEmailBox($email))<0)
			echo "<H2><CENTER>It was not possible to determine if <TT>$email</TT> is a valid deliverable e-mail box address.</CENTER></H2>\n";
		else
			echo "<H2><CENTER><TT>$email</TT> is ".($result ? "" : "not ")."a valid deliverable e-mail box address.</CENTER></H2>\n";
	}
	else
	{
		$port=(strcmp($port=getenv("SERVER_PORT"),"") ? intval($port) : 80);
		$site="http://".(strcmp($site=getenv("SERVER_NAME"),"") ? $site : "localhost").($port==80 ? "" : ":".$port).GetEnv("REQUEST_URI");
		echo "<H2>Access this page using a URL like: $site?email=<A HREF=\"$site?email=mlemos@acm.org\"><TT>your@test.email.here</TT></A></H2>\n";
	}
?>
<HR>
</BODY>
</HTML>
